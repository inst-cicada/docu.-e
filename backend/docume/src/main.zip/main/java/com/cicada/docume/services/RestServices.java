package com.cicada.docume.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.stereotype.Service;

import com.cicada.docume.payloads.CommonParamsResponseBody;
import com.google.gson.Gson;

@Service
public class RestServices {

    public static final Logger logger = LoggerFactory.getLogger(RestServices.class);

    public String getPreloadedInfo(ServerHttpRequest request) {
        try {
            CommonParamsResponseBody repsonseBody = new CommonParamsResponseBody();
            repsonseBody
                    .setOrigin(request.getRemoteAddress().getAddress() + ":" + request.getRemoteAddress().getPort());
            return new Gson().toJson(repsonseBody);
        } catch (Exception e) {
            logger.error("Something went wrong while getting the network stats", e);
            return "N/A";
        }
    }
}
